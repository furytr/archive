﻿-----------------------
# README
-----------------------
ZomBiz is an amazing html5 template for any corporate, finance or other business agencies. Our designers designed this with eye-catching backgrounds and fonts 
which will make your visitors love this eye-catchy user interface. This outstanding responsive template coded in bootstrap3 and CSS3 by our developer. This super 
responsive template offers fantastic animations, modern design with full customizability so you will get full control to change and update as you want.

Template Info:
-----------------------
Name: 		ZomBiz - Free Bootstrap HTML5 Template
Version: 	1.0
Author: 	ThemeSINE
Twitter:	https://twitter.com/themesine
Website: 	https://www.themesine.com/



Changelog:
-----------------------
Version 1.0 30-03-2018
- initial release


Credits
-----------------------
- Twitter Bootstrap http://getbootstrap.com
- jQuery http://jquery.org
- Owl Carousel https://owlcarousel2.github.io/OwlCarousel2/
- Font Awesome http://fontawesome.io
- jQuery slimScroll http://rocha.la/jQuery-slimScroll
- Linearicons https://linearicons.com/
- Pexels https://www.pexels.com/
- Unsplash https://unsplash.com/
